/*  _____ _______         _                      _
 * |_   _|__   __|       | |                    | |
 *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
 *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
 *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / /
 * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
 *                                _
 *              ___ ___ ___ _____|_|_ _ _____
 *             | . |  _| -_|     | | | |     |  LICENCE
 *             |  _|_| |___|_|_|_|_|___|_|_|_|
 *             |_|
 *
 * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
 *
 * Tento zdrojový kód je součástí výukových seriálů na
 * IT sociální síti WWW.ITNETWORK.CZ
 *
 * Kód spadá pod licenci prémiového obsahu a vznikl díky podpoře
 * našich členů. Je určen pouze pro osobní užití a nesmí být šířen.
 * Více informací na http://www.itnetwork.cz/licence
 */

package cz.itnetwork.recorder.models

import io.realm.Realm
import io.realm.RealmObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

open class Income: RealmObject(),Transaction, Realm.Transaction {
    override var amount: Int?=null

    override var date: LocalDateTime?
        get() = if (rawDate!=null) LocalDateTime.parse(rawDate, DateTimeFormatter.ISO_DATE_TIME) else null

        set(value) {
            rawDate = value?.format(DateTimeFormatter.ISO_DATE_TIME)
        }

        var rawDate:String?=null
}
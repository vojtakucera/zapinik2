/*  _____ _______         _                      _
 * |_   _|__   __|       | |                    | |
 *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
 *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
 *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / /
 * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
 *                                _
 *              ___ ___ ___ _____|_|_ _ _____
 *             | . |  _| -_|     | | | |     |  LICENCE
 *             |  _|_| |___|_|_|_|_|___|_|_|_|
 *             |_|
 *
 * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
 *
 * Tento zdrojový kód je součástí výukových seriálů na
 * IT sociální síti WWW.ITNETWORK.CZ
 *
 * Kód spadá pod licenci prémiového obsahu a vznikl díky podpoře
 * našich členů. Je určen pouze pro osobní užití a nesmí být šířen.
 * Více informací na http://www.itnetwork.cz/licence
 */

package cz.itnetwork.recorder

import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import cz.itnetwork.recorder.models.Income
import cz.itnetwork.recorder.models.Transaction
import java.time.format.DateTimeFormatter

class TransactionsAdapter(val transactions: List<Transaction>): RecyclerView.Adapter<TransactionsAdapter.MyViewHolder>() {

    class MyViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val iVIcon: ImageView = view.findViewById(R.id.iv_icon)
        val tVTitle: TextView = view.findViewById(R.id.tv_title)
        val tVType: TextView = view.findViewById(R.id.tv_transaction_type)
        val tVDate: TextView = view.findViewById(R.id.tv_date)
        val tvCurrency: TextView = view.findViewById(R.id.tv_currency)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.transaction_row, parent, false)

        return MyViewHolder(view)
    }

    override fun getItemCount(): Int = transactions.size

override fun onBindViewHolder(viewHolder: MyViewHolder, index: Int) {
    val transaction = transactions[index]
    val context = viewHolder.view.context

    when (transaction) {
        is Income -> {
            viewHolder.tVTitle.text = "${transaction.amount}"
            viewHolder.tVType.setText(R.string.income)
            viewHolder.iVIcon.setImageResource(R.mipmap.right_button)
            viewHolder.tVTitle.setTextColor(ContextCompat.getColor(viewHolder.view.context, R.color.colorIncome))
            viewHolder.tvCurrency.setTextColor(ContextCompat.getColor(viewHolder.view.context, R.color.colorIncome))
        }
        else -> {
            viewHolder.tVTitle.text = "-${transaction.amount}"
            viewHolder.tVType.setText(R.string.expense)
            viewHolder.iVIcon.setImageResource(R.mipmap.left_button)
            viewHolder.tVTitle.setTextColor(ContextCompat.getColor(context, R.color.colorExpense))
            viewHolder.tvCurrency.setTextColor(ContextCompat.getColor(context, R.color.colorExpense))
        }
    }
    viewHolder.tVDate.text = transaction.date.format(formatter)?:"Null"
}

    companion object {
        private val formatter = DateTimeFormatter.ofPattern("d/M/y")
    }
}